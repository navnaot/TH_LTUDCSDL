/**
 * 
 */
/**
 * 
 */
module lab02 {
}