package lab02;

import java.util.ArrayList;
import java.util.Scanner;

public class Department {
	
	private int id;
    public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public ArrayList<Employee> getEmployees() {
		return employees;
	}



	public void setEmployees(ArrayList<Employee> employees) {
		this.employees = employees;
	}

	private String name;
    private ArrayList<Employee> employees;

    // Constructor
    public Department(int id, String name) {
        this.id = id;
        this.name = name;
        this.employees = new ArrayList<>();
    }
    
    // Constructor
    public Department() {
        this.employees = new ArrayList<>();
    }

   

    // Phương thức nhập thông tin cho phòng ban từ bàn phím
    public void inputDepartment() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhập thông tin phòng ban:");
        System.out.print("ID: ");
        this.id = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng mới
        System.out.print("Name: ");
        this.name = scanner.nextLine();

        // Nhập thông tin cho từng nhân viên trong phòng ban
        int numOfEmployees;
        System.out.print("Nhập số lượng nhân viên trong phòng ban: ");
        numOfEmployees = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng mới
        for (int i = 0; i < numOfEmployees; i++) {
            Employee employee = new Employee();
            employee.inputEmployee();
            employees.add(employee);
        }
    }

    // Phương thức xuất thông tin của phòng ban ra màn hình
    public void displayDepartment() {
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
        System.out.println("Danh sách nhân viên trong phòng ban:");
        for (Employee employee : employees) {
            employee.displayEmployee();
        }
    }
}
