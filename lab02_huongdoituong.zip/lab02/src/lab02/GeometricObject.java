package lab02;

public interface GeometricObject {
	double getPerimeter();
    double getArea();
}
