package lab02;

public class lab08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Circle circle = new Circle();
        System.out.println(circle); 
        System.out.println("Area of the circle: " + circle.getArea());

        
        Circle circleWithRadius = new Circle(2.5);
        System.out.println(circleWithRadius);
        System.out.println("Area of the circle with radius 2.5: " + circleWithRadius.getArea());

        
        Circle circleWithColor = new Circle(3.0, "blue");
        System.out.println(circleWithColor);
        System.out.println("Area of the circle with radius 3.0 and color blue: " + circleWithColor.getArea());

     
        Cylinder cylinder = new Cylinder();
        System.out.println(cylinder); // Calls toString()
        System.out.println("Volume of the cylinder: " + cylinder.getVolume());

        
        Cylinder cylinderWithRadius = new Cylinder(2.5);
        System.out.println(cylinderWithRadius);
        System.out.println("Volume of the cylinder with radius 2.5: " + cylinderWithRadius.getVolume());

       
        Cylinder cylinderWithHeight = new Cylinder(2.5, 5.0);
        System.out.println(cylinderWithHeight);
        System.out.println("Volume of the cylinder with radius 2.5 and height 5.0: " + cylinderWithHeight.getVolume());

     
        Cylinder cylinderWithColor = new Cylinder(3.0, 4.0, "green");
        System.out.println(cylinderWithColor);
        System.out.println("Volume of the cylinder with radius 3.0, height 4.0 and color green: " + cylinderWithColor.getVolume());
    }

}
