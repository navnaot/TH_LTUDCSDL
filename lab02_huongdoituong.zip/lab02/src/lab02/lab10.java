package lab02;

public class lab10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ACircle circle = new ACircle(2.0, "blue", false);
        Rectangle rectangle = new Rectangle(2.0, 3.0, "green", true);
        Square square = new Square(4.0, "yellow", true);

        System.out.println(circle);
        System.out.println("Area of circle: " + circle.getArea());
        System.out.println("Perimeter of circle: " + circle.getPerimeter());

        System.out.println(rectangle);
        System.out.println("Area of rectangle: " + rectangle.getArea());
        System.out.println("Perimeter of rectangle: " + rectangle.getPerimeter());
        
        System.out.println(square);
        System.out.println("Area of square: " + rectangle.getArea());
        System.out.println("Perimeter of square: " + rectangle.getPerimeter());
	}

}
