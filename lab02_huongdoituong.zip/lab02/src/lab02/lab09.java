package lab02;

public class lab09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Person person = new Person("Alice", "123 Maple Street");
        System.out.println(person);

   
        Student student = new Student("Bob", "456 Oak Avenue", "Computer Science", 2, 1500.0);
        System.out.println(student);

     
        Staff staff = new Staff("Charlie", "789 Pine Road", "Engineering School", 50000.0);
        System.out.println(staff);
	}

}
