package lab02;

public class lab11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICircle circle = new ICircle(5.0);
        System.out.println("Original Circle perimeter: " + circle.getPerimeter());
        System.out.println("Original Circle area: " + circle.getArea());

        ResizableCircle resizableCircle = new ResizableCircle(10.0);
        System.out.println("Resizable Circle perimeter: " + resizableCircle.getPerimeter());
        System.out.println("Resizable Circle area: " + resizableCircle.getArea());

        resizableCircle.resize(10);
        System.out.println("Resizable Circle perimeter: " + resizableCircle.getPerimeter());
        System.out.println("Resizable Circle area: " + resizableCircle.getArea());
	}

}
