package lab02;

import java.util.Scanner;

public class Book {
	private int id;
    private String title;
    private double price;
    private int catalogId; // Trường mới để thể hiện quan hệ 1-nhiều với Catalog
    
    public Book() {
    	
    }

    // Constructor
    public Book(int id, String title, double price, int catalogId) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.catalogId = catalogId;
    }

    // Phương thức Get/Set cho thuộc tính id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Phương thức Get/Set cho thuộc tính title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Phương thức Get/Set cho thuộc tính price
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Phương thức Get/Set cho thuộc tính catalogId
    public int getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }

    // Phương thức toString
    @Override
    public String toString() {
        return "Book [id=" + id + ", title=" + title + ", price=" + price + ", catalogId=" + catalogId + "]";
    }
    
    /**
     * Hàm nhập
     */
    public void inputBook() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhập thông tin sách:");
        System.out.print("ID: ");
        this.id = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng mới
        System.out.print("Title: ");
        this.title = scanner.nextLine();
        System.out.print("Price: ");
        this.price = scanner.nextDouble();
        System.out.print("Catalog ID: ");
        this.catalogId = scanner.nextInt();
    }
    
    /**
     * Hàm Xuất
     */
    public void displayBook() {
        System.out.println("ID: " + this.id);
        System.out.println("Title: " + this.title);
        System.out.println("Price: " + this.price);
        System.out.println("Catalog ID: " + this.catalogId);
    }
}
