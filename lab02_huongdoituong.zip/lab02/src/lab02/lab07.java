package lab02;

public class lab07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Tạo một đối tượng Department và nhập thông tin từ bàn phím
        Department department = new Department();
        department.inputDepartment();
        // In thông tin phòng ban vừa nhập
        System.out.println("\nThông tin phòng ban vừa nhập:");
        department.displayDepartment();
	}

}
