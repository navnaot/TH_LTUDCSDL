package lab02;

import java.util.ArrayList;
import java.util.Scanner;

public class lab02_3 {
	public static class SinhVien {
	    private String mssv;
	    private String hoTen;
	    private double diemTB;

	    // Constructor
	    public SinhVien(String mssv, String hoTen, double diemTB) {
	        this.mssv = mssv;
	        this.hoTen = hoTen;
	        this.diemTB = diemTB;
	    }

	    // Phương thức toString
	    @Override
	    public String toString() {
	        return "MSSV: " + mssv + "\nHọ tên: " + hoTen + "\nĐiểm trung bình: " + diemTB;
	    }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        ArrayList<SinhVien> danhSachSV = new ArrayList<>();

        // Nhập thông tin của 5 sinh viên
        for (int i = 1; i <= 5; i++) {
            System.out.println("Nhập thông tin sinh viên thứ " + i + ":");
            System.out.println("MSSV:");
            String mssv = scanner.nextLine();
            System.out.println("Họ và tên:");
            String hoTen = scanner.nextLine();
            System.out.println("Điểm trung bình:");
            double diemTB = scanner.nextDouble();
            scanner.nextLine(); // Đọc bỏ dòng mới
            danhSachSV.add(new SinhVien(mssv, hoTen, diemTB));
        }

        // In danh sách sinh viên đã nhập
        System.out.println("\nDanh sách sinh viên:");
        for (SinhVien sv : danhSachSV) {
            System.out.println(sv);
            System.out.println();
        }
	}

}
