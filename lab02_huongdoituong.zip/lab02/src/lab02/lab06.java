package lab02;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class lab06 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Khai báo Set để lưu danh sách sinh viên
        Set<SinhVien> danhSachSinhVien = new HashSet<>();

        // Khai báo Map để lưu danh sách sinh viên với mssv là key
        Map<String, SinhVien> mapSinhVien = new HashMap<>();

        // Nhập thông tin của 5 sinh viên
        for (int i = 0; i < 5; i++) {
            System.out.println("Nhập thông tin sinh viên thứ " + (i + 1) + ":");
            System.out.print("MSSV: ");
            String mssv = scanner.nextLine();
            System.out.print("Họ và tên: ");
            String hoTen = scanner.nextLine();
            System.out.print("Điểm trung bình: ");
            double diemTB = scanner.nextDouble();
            scanner.nextLine(); // Đọc bỏ dòng mới

            // Tạo đối tượng SinhVien
            SinhVien sinhVien = new SinhVien(mssv, hoTen, diemTB);

            // Thêm sinh viên vào danh sách sử dụng Set
            danhSachSinhVien.add(sinhVien);

            // Thêm sinh viên vào danh sách sử dụng Map với mssv là key
            mapSinhVien.put(mssv, sinhVien);
        }

        // In danh sách sinh viên từ Set
        System.out.println("\nDanh sách sinh viên từ Set:");
        for (SinhVien sv : danhSachSinhVien) {
            System.out.println(sv);
        }

        // In danh sách sinh viên từ Map
        System.out.println("\nDanh sách sinh viên từ Map:");
        for (Map.Entry<String, SinhVien> entry : mapSinhVien.entrySet()) {
            System.out.println("MSSV: " + entry.getKey());
            System.out.println(entry.getValue());
        }
    }
	
	public static class SinhVien {
	    private String mssv;
	    private String hoTen;
	    private double diemTB;

	    // Constructor
	    public SinhVien(String mssv, String hoTen, double diemTB) {
	        this.mssv = mssv;
	        this.hoTen = hoTen;
	        this.diemTB = diemTB;
	    }

	    // Phương thức toString
	    @Override
	    public String toString() {
	        return "MSSV: " + mssv + "\nHọ tên: " + hoTen + "\nĐiểm trung bình: " + diemTB;
	    }
	}

}
