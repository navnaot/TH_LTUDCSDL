package lab02;

public class lab02_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HinhTron ht = new HinhTron(10.0);
		System.out.println(ht);
	}
	public static class HinhTron {
	    private double banKinh;

	    // Constructor không đối số
	    public HinhTron() {
	    }

	    // Constructor có một đối số
	    public HinhTron(double banKinh) {
	        this.banKinh = banKinh;
	    }

	    // Phương thức Get/Set cho thuộc tính banKinh
	    public double getBanKinh() {
	        return banKinh;
	    }

	    public void setBanKinh(double banKinh) {
	        this.banKinh = banKinh;
	    }

	    // Phương thức tính chu vi
	    public double tinhChuVi() {
	        return 2 * Math.PI * banKinh;
	    }

	    // Phương thức toString
	    @Override
	    public String toString() {
	        return "Bán kính: " + banKinh + "\nChu vi: " + tinhChuVi();
	    }
	}

}
