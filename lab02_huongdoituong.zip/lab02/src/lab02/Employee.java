package lab02;

import java.util.Scanner;

public class Employee {
	private int id;
    private String name;
    private double salary;
    
    public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// Constructor
    public Employee() {
        
    }

    // Constructor
    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }


    // Phương thức nhập thông tin cho nhân viên từ bàn phím
    public void inputEmployee() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhập thông tin nhân viên:");
        System.out.print("ID: ");
        this.id = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng mới
        System.out.print("Name: ");
        this.name = scanner.nextLine();
    }

    // Phương thức xuất thông tin của nhân viên ra màn hình
    public void displayEmployee() {
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
    }
}
