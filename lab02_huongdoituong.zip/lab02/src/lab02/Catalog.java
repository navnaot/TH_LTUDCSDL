package lab02;

import java.util.ArrayList;
import java.util.Scanner;

public class Catalog {
	private int id;
    private String name;
    private ArrayList<Book> books;
    
    public Catalog() {
    }

    // Constructor
    public Catalog(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Phương thức Get/Set cho thuộc tính id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Phương thức Get/Set cho thuộc tính name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Phương thức toString
    @Override
    public String toString() {
        return "Catalog [id=" + id + ", name=" + name + "]";
    }
    
 // Phương thức nhập thông tin cho danh mục từ bàn phím
    public void inputCatalog() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhập thông tin danh mục:");
        System.out.print("ID: ");
        this.id = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ dòng mới
        System.out.print("Name: ");
        this.name = scanner.nextLine();
        this.books = new ArrayList<Book>();
    }

    // Phương thức xuất thông tin của danh mục ra màn hình
    public void displayCatalog() {
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
        for(Book book:this.books) {
        	System.out.println(book);
        }
    }
    
 // Phương thức thêm một sách vào danh mục
    public void addBook(Book book) {
        books.add(book);
    }
}
