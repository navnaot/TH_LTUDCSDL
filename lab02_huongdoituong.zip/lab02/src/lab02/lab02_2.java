package lab02;

public class lab02_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HinhChuNhat hcn = new HinhChuNhat(10, 12);
		System.out.println(hcn);
	}
	public static class HinhChuNhat {
	    private double dai;
	    private double rong;

	    // Constructor không đối số
	    public HinhChuNhat() {
	    }

	    // Constructor có hai đối số
	    public HinhChuNhat(double dai, double rong) {
	        this.dai = dai;
	        this.rong = rong;
	    }

	    // Phương thức Get/Set cho thuộc tính dai
	    public double getDai() {
	        return dai;
	    }

	    public void setDai(double dai) {
	        this.dai = dai;
	    }

	    // Phương thức Get/Set cho thuộc tính rong
	    public double getRong() {
	        return rong;
	    }

	    public void setRong(double rong) {
	        this.rong = rong;
	    }

	    // Phương thức tính chu vi
	    public double tinhChuVi() {
	        return 2 * (dai + rong);
	    }

	    // Phương thức tính diện tích
	    public double tinhDienTich() {
	        return dai * rong;
	    }

	    // Phương thức toString
	    @Override
	    public String toString() {
	        return "Chiều dài: " + dai + "\nChiều rộng: " + rong + "\nChu vi: " + tinhChuVi() + "\nDiện tích: " + tinhDienTich();
	    }
	}

}
