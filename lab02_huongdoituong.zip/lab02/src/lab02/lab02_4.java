package lab02;

import java.util.ArrayList;

public class lab02_4 {
	public static void main(String[] args) {
        // Khai báo danh sách các đối tượng NhanVien
        ArrayList<NhanVien> danhSachNhanVien = new ArrayList<>();

        // Thêm các đối tượng NhanVien vào danh sách
        danhSachNhanVien.add(new NhanVien("Nguyen Van A", 20, 10000000));
        danhSachNhanVien.add(new NhanVien("Nguyen Van B", 22, 12000000));
        danhSachNhanVien.add(new NhanVien("Nguyen Van C", 25, 15000000));
        danhSachNhanVien.add(new NhanVien("Nguyen Van D", 18, 8000000));
        danhSachNhanVien.add(new NhanVien("Nguyen Van E", 19, 9000000));

        // In danh sách nhân viên
        System.out.println("Danh sách nhân viên:");
        for (NhanVien nv : danhSachNhanVien) {
            System.out.println(nv);
            System.out.println();
        }

        // Tính trung bình lương toàn nhân viên
        double tongLuong = 0;
        for (NhanVien nv : danhSachNhanVien) {
            tongLuong += nv.getLuong();
        }
        double trungBinhLuong = tongLuong / danhSachNhanVien.size();

        System.out.println("Trung bình lương toàn nhân viên: " + trungBinhLuong);
    }
	
	public static class NhanVien {
	    private String hoTen;
	    private int ngayCong;
	    private double luongCoBan;

	    // Constructor không đối số
	    public NhanVien() {
	    }

	    // Constructor có 3 đối số
	    public NhanVien(String hoTen, int ngayCong, double luongCoBan) {
	        this.hoTen = hoTen;
	        this.ngayCong = ngayCong;
	        this.luongCoBan = luongCoBan;
	    }

	    // Phương thức Get/Set cho thuộc tính hoTen
	    public String getHoTen() {
	        return hoTen;
	    }

	    public void setHoTen(String hoTen) {
	        this.hoTen = hoTen;
	    }

	    // Phương thức Get/Set cho thuộc tính ngayCong
	    public int getNgayCong() {
	        return ngayCong;
	    }

	    public void setNgayCong(int ngayCong) {
	        this.ngayCong = ngayCong;
	    }

	    // Phương thức Get/Set cho thuộc tính luongCoBan
	    public double getLuongCoBan() {
	        return luongCoBan;
	    }

	    public void setLuongCoBan(double luongCoBan) {
	        this.luongCoBan = luongCoBan;
	    }

	    // Phương thức tính lương
	    public double getLuong() {
	        return ngayCong * luongCoBan;
	    }

	    // Phương thức toString
	    @Override
	    public String toString() {
	        return "Họ và tên: " + hoTen + "\nNgày công: " + ngayCong + "\nLương cơ bản: " + luongCoBan + "\nLương: " + getLuong();
	    }
	}
}
