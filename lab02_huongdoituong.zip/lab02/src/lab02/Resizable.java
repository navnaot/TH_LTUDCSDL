package lab02;

public interface Resizable {
	void resize(int percent);
}
