package lab02;

public class lab02_5 {
	public static void main(String[] args) {
		
		 // Tạo một đối tượng Catalog và nhập thông tin từ bàn phím
        Catalog catalog = new Catalog();
        catalog.inputCatalog();

        // Tạo một đối tượng Book và nhập thông tin từ bàn phím
        Book book = new Book();
        book.inputBook();

        // Thêm sách vào danh mục
        catalog.addBook(book);

        // In thông tin danh mục vừa nhập
        System.out.println("\nThông tin danh mục vừa nhập:");
        catalog.displayCatalog();
    }
	
}
