/**
 * 
 */
/**
 * 
 */
module lab01 {
}