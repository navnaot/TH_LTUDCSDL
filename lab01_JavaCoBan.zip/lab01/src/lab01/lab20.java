package lab01;

import java.util.ArrayList;
import java.util.Scanner;

public class lab20 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập ArrayList thứ nhất từ người dùng
        ArrayList<Integer> arrayList1 = new ArrayList<>();
        System.out.println("Nhập các phần tử của ArrayList thứ nhất (nhập 0 để kết thúc):");
        int input;
        while ((input = scanner.nextInt()) != 0) {
            arrayList1.add(input);
        }

        // Nhập ArrayList thứ hai từ người dùng
        ArrayList<Integer> arrayList2 = new ArrayList<>();
        System.out.println("Nhập các phần tử của ArrayList thứ hai (nhập 0 để kết thúc):");
        while ((input = scanner.nextInt()) != 0) {
            arrayList2.add(input);
        }

        // So sánh hai ArrayList
        boolean equals = arrayList1.equals(arrayList2);

        // In ra kết quả
        System.out.println("Hai ArrayList giống nhau: " + equals);
    }

}
