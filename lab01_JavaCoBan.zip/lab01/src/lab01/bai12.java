package lab01;

import java.util.Scanner;

public class bai12 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập điểm toán
        System.out.println("Nhập điểm môn Toán:");
        double diemToan = scanner.nextDouble();

        // Nhập điểm lý
        System.out.println("Nhập điểm môn Lý:");
        double diemLy = scanner.nextDouble();

        // Nhập điểm hóa
        System.out.println("Nhập điểm môn Hóa:");
        double diemHoa = scanner.nextDouble();

        // Tính điểm trung bình
        double diemTrungBinh = (diemToan + diemLy + diemHoa) / 3;

        // In ra điểm trung bình
        System.out.println("Điểm trung bình: " + diemTrungBinh);

        // Xếp loại
        if (diemTrungBinh < 5) {
            System.out.println("Rớt!");
        } else if (diemTrungBinh >= 5 && diemTrungBinh < 7) {
            System.out.println("Trung Bình!");
        } else if (diemTrungBinh >= 7 && diemTrungBinh < 8) {
            System.out.println("Khá!");
        } else if (diemTrungBinh >= 8 && diemTrungBinh < 9) {
            System.out.println("Giỏi!");
        } else {
            System.out.println("Xuất Sắc!");
        }
    }

}
