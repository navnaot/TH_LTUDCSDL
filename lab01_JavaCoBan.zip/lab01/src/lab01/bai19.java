package lab01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class bai19 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập ArrayList từ người dùng
        ArrayList<Integer> arrayList = new ArrayList<>();
        System.out.println("Nhập các phần tử của ArrayList (nhập 0 để kết thúc):");
        int input;
        while ((input = scanner.nextInt()) != 0) {
            arrayList.add(input);
        }

        // Sắp xếp ArrayList theo thứ tự tăng dần
        Collections.sort(arrayList);

        // In ra ArrayList sau khi đã sắp xếp
        System.out.println("ArrayList sau khi sắp xếp:");
        System.out.println(arrayList);
    }

}
