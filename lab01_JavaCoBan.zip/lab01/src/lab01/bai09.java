package lab01;

import java.util.Scanner;

public class bai09 {

	public static double[] nhapMang(int n) {
        Scanner scanner = new Scanner(System.in);
        double[] arr = new double[n];
        System.out.println("Nhập vào các phần tử của mảng:");
        for (int i = 0; i < n; i++) {
            System.out.print("Phần tử thứ " + (i + 1) + ": ");
            arr[i] = scanner.nextDouble();
        }
        return arr;
    }

    // Hàm xuất mảng số thực
    public static void xuatMang(double[] arr) {
        System.out.println("Các phần tử của mảng:");
        for (double element : arr) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    // Hàm tìm phần tử lớn nhất trong mảng số thực
    public static double timMax(double[] arr) {
        double max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập vào kích thước của mảng: ");
        int size = scanner.nextInt();

        double[] array = nhapMang(size); // Gọi hàm nhập mảng

        xuatMang(array); // Gọi hàm xuất mảng

        double max = timMax(array); // Gọi hàm tìm phần tử lớn nhất trong mảng
        System.out.println("Phần tử lớn nhất trong mảng là: " + max);
    }

}
