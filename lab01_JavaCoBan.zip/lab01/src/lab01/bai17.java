package lab01;

import java.util.Scanner;

public class bai17 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập chuỗi từ người dùng
        System.out.println("Nhập vào một chuỗi:");
        String chuoi = scanner.nextLine();

        // Đếm số lượng ký tự chữ cái, khoảng trắng và ký tự số
        int soKiTuChuCai = 0;
        int soKhoangTrang = 0;
        int soKiTuSo = 0;

        for (int i = 0; i < chuoi.length(); i++) {
            char kiTu = chuoi.charAt(i);
            if (Character.isLetter(kiTu)) {
                soKiTuChuCai++;
            } else if (Character.isWhitespace(kiTu)) {
                soKhoangTrang++;
            } else if (Character.isDigit(kiTu)) {
                soKiTuSo++;
            }
        }

        // In ra số lượng ký tự chữ cái, số lượng khoảng trắng và số lượng ký tự số
        System.out.println("Số ký tự chữ cái: " + soKiTuChuCai);
        System.out.println("Số khoảng trắng: " + soKhoangTrang);
        System.out.println("Số ký tự số: " + soKiTuSo);
    }

}
