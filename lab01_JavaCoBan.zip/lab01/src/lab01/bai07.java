package lab01;

import java.util.Scanner;

public class bai07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);

	        System.out.println("Nhập vào số thứ nhất: ");
	        int a = scanner.nextInt();

	        System.out.println("Nhập vào số thứ hai: ");
	        int b = scanner.nextInt();

	        System.out.println("Nhập vào số thứ ba: ");
	        int c = scanner.nextInt();

	        int max = a; // Giả sử số đầu tiên là lớn nhất ban đầu

	        // So sánh để tìm số lớn nhất
	        if (b > max) {
	            max = b;
	        }
	        if (c > max) {
	            max = c;
	        }

	        System.out.println("Số lớn nhất là: " + max);
	}

}
