package lab01;

import java.util.Scanner;

public class bai08 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập vào số tháng (1-12): ");
        int month = scanner.nextInt();

        if (month >= 1 && month <= 12) {
            String quarter;
            switch (month) {
                case 1:
                case 2:
                case 3:
                    quarter = "Quý 1";
                    break;
                case 4:
                case 5:
                case 6:
                    quarter = "Quý 2";
                    break;
                case 7:
                case 8:
                case 9:
                    quarter = "Quý 3";
                    break;
                default:
                    quarter = "Quý 4";
                    break;
            }
            System.out.println("Tháng " + month + " tương ứng với " + quarter);
        } else {
            System.out.println("Lỗi: Số tháng không hợp lệ.");
        }
	}
}
