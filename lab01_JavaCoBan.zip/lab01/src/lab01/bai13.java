package lab01;

import java.util.Scanner;

public class bai13 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập vào một số nguyên:");
        int number = scanner.nextInt();

        // Kiểm tra xem số có phải là bội số của cả 3 và 5 hay không
        if (number % 3 == 0 && number % 5 == 0) {
            System.out.println(number + " là bội số của cả 3 và 5.");
        } else {
            System.out.println(number + " không phải là bội số của cả 3 và 5.");
        }
    }

}
