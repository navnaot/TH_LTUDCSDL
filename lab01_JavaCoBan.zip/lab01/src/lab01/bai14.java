package lab01;

import java.util.Scanner;

public class bai14 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập vào một số nguyên dương:");
        int number = scanner.nextInt();

        // Kiểm tra xem số có phải là số chính phương hay không
        if (isPerfectSquare(number)) {
            System.out.println(number + " là số chính phương.");
        } else {
            System.out.println(number + " không phải là số chính phương.");
        }
    }

    // Phương thức kiểm tra số chính phương
    public static boolean isPerfectSquare(int n) {
        int sqrt = (int) Math.sqrt(n);
        return sqrt * sqrt == n;
    }

}
