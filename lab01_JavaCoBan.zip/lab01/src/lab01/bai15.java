package lab01;

import java.util.Scanner;

public class bai15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);

	        System.out.println("Nhập vào tên của bạn:");
	        String tenNguoiDung = scanner.nextLine();

	        System.out.println("Hello! " + tenNguoiDung);
	}

}
