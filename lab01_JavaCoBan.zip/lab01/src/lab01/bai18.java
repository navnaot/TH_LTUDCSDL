package lab01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class bai18 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập ArrayList từ người dùng
        ArrayList<String> arrayList = new ArrayList<>();
        System.out.println("Nhập các phần tử của ArrayList (nhập 'done' để kết thúc):");
        String input;
        while (!(input = scanner.nextLine()).equals("done")) {
            arrayList.add(input);
        }

        // In ra ArrayList ban đầu
        System.out.println("ArrayList ban đầu:");
        System.out.println(arrayList);

        // Đảo ngược ArrayList
        Collections.reverse(arrayList);

        // In ra ArrayList đã đảo ngược
        System.out.println("ArrayList sau khi đảo ngược:");
        System.out.println(arrayList);
    }

}
