package lab01;

import java.util.Scanner;

public class bai16 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập chuỗi từ người dùng
        System.out.println("Nhập vào một chuỗi:");
        String chuoi = scanner.nextLine();

        // In ra chuỗi đảo ngược
        System.out.println("Chuỗi đảo ngược là:");
        String chuoiDaoNguoc = daoNguocChuoi(chuoi);
        System.out.println(chuoiDaoNguoc);
    }

    // Phương thức đảo ngược chuỗi
    public static String daoNguocChuoi(String chuoi) {
        StringBuilder builder = new StringBuilder(chuoi);
        return builder.reverse().toString();
    }

}
