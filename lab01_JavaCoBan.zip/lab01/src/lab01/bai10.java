package lab01;

import java.util.Scanner;

public class bai10 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập vào họ và tên: ");
        String hoTen = scanner.nextLine();

        // Tách họ và tên
        String[] parts = hoTen.split(" ");
        
        // In ra họ
        System.out.println("Họ: " + parts[0]);
        
        // In ra tên
        System.out.println("Tên: " + parts[parts.length - 1]);
    }

}
