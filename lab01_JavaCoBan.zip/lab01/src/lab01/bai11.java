package lab01;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class bai11 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập ngày tháng năm theo định dạng dd/MM/yyyy
        System.out.println("Nhập ngày tháng năm (dd/MM/yyyy): ");
        String inputDateStr = scanner.nextLine();

        // Lấy ngày tháng hiện tại
        Date currentDate = new Date();

        // Chuyển đổi ngày tháng nhập vào thành đối tượng Date
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date inputDate = null;
        try {
            inputDate = dateFormat.parse(inputDateStr);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }

        // So sánh ngày tháng nhập vào với ngày tháng hiện tại
        if (inputDate.before(currentDate)) {
            System.out.println("Ngày " + inputDateStr + " đã qua.");
        } else if (inputDate.after(currentDate)) {
            System.out.println("Ngày " + inputDateStr + " sẽ đến.");
        } else {
            System.out.println("Ngày " + inputDateStr + " là ngày hiện tại.");
        }
    }

}
